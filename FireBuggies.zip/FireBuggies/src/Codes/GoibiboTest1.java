package Codes;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GoibiboTest1  {
	WebDriver driver;
	 
	File src = new File("./Config/fireBug.property");
	FileInputStream fi= new FileInputStream(src);
	Properties pro = new Properties();
	pro.load(fi);
	 @Test
	 System.setProperty("webdriver.chrome.driver", "C://Program Files (x86)//Google//Chrome//Application//chrome.exe");
	 
 }
	 


