package Codes;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClassFile {
	private static WebDriver driver;
	 public static void main(String[] args)
     {
    	 System.setProperty("webdriver.chrome.driver", "D:/Users/ADM-IG-HWDLAB1B/Desktop/chromedriver.exe");
    	 driver = new ChromeDriver();
    	 driver.get("https://www.goibibo.com/");

}
}