package pompackages.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class PageClass {
	File src;
	FileInputStream  fis;
	SAXReader saxreader;
	Document document;
		   WebDriver driver;
		   
	public PageClass(WebDriver driver) 
	        {
		src= new File("./Config/Working.xml");
		 try {
			fis = new FileInputStream(src);
			 saxreader = new SAXReader();
			 document = saxreader.read(fis);
				   this.driver = driver;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		   }

	public void Click(String xPath)
	       {
		      driver.findElement(By.xpath(xPath)).click();
	       }

	public void SendValues(String value , String xPath)
	{
		driver.findElement(By.xpath(xPath)).sendKeys(value);
	}

	public void Clear(String xPath)
	{
		driver.findElement(By.xpath(xPath)).clear();
	}

	public void DropDown(String xPath, int index)
	{
		Select City= new Select(driver.findElement(By.xpath(xPath)));
	    City.selectByIndex(index);    
	}
	
	public void CheckBox(String xPath)
	{
		 List<WebElement> check = driver.findElements(By.xpath(xPath));
		 check.get(0).click();
	}
	
	public void dateSelector(String xPath, String data)
	{
		WebElement dateWidget = driver.findElement(By.xpath(xPath));
		List<WebElement> columns=dateWidget.findElements(By.tagName(""));

		for (WebElement cell: columns){
		   if (cell.getText().equals(data)){
		      cell.findElement(By.linkText(data)).click();
		      break;
		 }
	   }
	}
	
	public String getXpath(String word)
	{
		return document.selectSingleNode(word).getText();
		//return driver.findElement(By.xpath(document.selectSingleNode("").getText())).toString();
	
	}
}

	

