package pompackages.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import pompackages.pages.PageClass;


public class TestPageClass {
	WebDriver driver;	
	 @Test
	  public void testMethod() throws Exception
	  {
	   System.setProperty("webdriver.chrome.driver","D:/Users/ADM-IG-HWDLAB1B/Desktop/chromedriver.exe");
		driver= new ChromeDriver();
		
		driver.get("https://www.goibibo.com/flights/");
		PageClass p = PageFactory.initElements(driver, PageClass.class);
	    //String s= "//Start";
		
		p.Click(p.getXpath("//Round_Way/Round_XPath"));
		Thread.sleep(3000);

}
	 @AfterClass
	 public void ending(){

			driver.close();
	 }
}